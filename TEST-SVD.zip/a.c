#include <stdio.h>
#include <stdlib.h>
#include <strings.h> //bzero function

#include <unistd.h>    //socket headers
#include <netdb.h>     //socket headers
#include <netinet/in.h>//socket headers

#include <pthread.h>   //for thread functions


#define BUFFER_SIZE 8

struct thread_data{
   int thread_id;
   int number_of_rows;
   int number_of_columns;
   double *data;
   int socket_number;
};

typedef struct thread_data thread_data;


extern void dgesvd( char* jobu, char* jobvt, int* m, int* n, double* a,
                int* lda, double* s, double* u, int* ldu, double* vt, int* ldvt,
                double* work, int* lwork, int* info );

extern void print_matrix( char* desc, int m, int n, double* a, int lda );



void *send_and_receive_tf(void *thread_arg);
int main(int argc, char *argv[]){

///////////////////////////////////////////////////////////////  FILE_READ  ///////////////////////////////////////////////////////////////

   //file pointer, gets data from the file given by first command line argument
   FILE *fp;
   fp = fopen(argv[1], "r");
   int total_row_number,total_column_number,i,j,nonzeros;
   //First line indicates number of rows and columns and nonzeros
   fscanf(fp,"%d",&total_row_number);
   printf("Number of rows : %d\n", total_row_number);
   fscanf(fp,"%d",&total_column_number);
   printf("Number of columns : %d\n", total_column_number);
   fscanf(fp,"%d\n",&nonzeros);
   printf("Number of nonzeros : %d\n", nonzeros);

   double ** full_matrix = (double **)malloc(total_row_number * sizeof(double *));
   for (i = 0; i < total_row_number; i++)
       full_matrix[i] = (double *)malloc(total_column_number * sizeof(double));

   for(i = 0; i < total_row_number ; i++)
      for(j = 0; j < total_column_number ; j++)
        full_matrix[i][j] = 0.0;

   //variables contain temporary values from the file when reading 
   int t1,t2;
   double t3;

   //Totally nonzeros is read from the file each one is seperated by a space and each enry by a line
   for(int i = 0 ; i < nonzeros * 3 ; i++){
      fscanf(fp,"%d",&t1);
      fscanf(fp,"%d",&t2);
      fscanf(fp,"%lf\n",&t3);  
      full_matrix[t1-1][t2-1] = t3;
   }




 double a[total_row_number*total_column_number];


  for(i = 0 ; i < total_row_number ; i++){
      for(j = 0 ; j < total_column_number ; j++){
          a[i*total_column_number + j] = full_matrix[i][j];
      }
   }

	int M = total_row_number;
        int N = total_column_number;
        int LDA = M;
 	int LDU = M;
	int LDVT = N;


        int m = M, n = N, lda = LDA, ldu = LDU, ldvt = LDVT, info, lwork;
        double wkopt;
        double* work;
        /* Local arrays */
        double s[N], u[LDU*M], vt[LDVT*N];

        /* Executable statements */
        printf( " DGESVD Example Program Results\n" );
        /* Query and allocate the optimal workspace */
        lwork = -1;
        dgesvd( "All", "All", &m, &n, a, &lda, s, u, &ldu, vt, &ldvt, &wkopt, &lwork,
         &info );
        lwork = (int)wkopt;
        work = (double*)malloc( lwork*sizeof(double) );
        /* Compute SVD */
        dgesvd( "All", "All", &m, &n, a, &lda, s, u, &ldu, vt, &ldvt, work, &lwork,
         &info );
        /* Check for convergence */
        if( info > 0 ) {        print_matrix( "Singular values", 1, n, s, 1 );

                printf( "The algorithm computing SVD failed to converge.\n" );
                exit( 1 );
        }
        /* Print singular values */
        //print_matrix( "Singular values", 1, n, s, 1 );
        /* Print left singular vectors */
        //print_matrix( "Left singular vectors (stored columnwise)", m, n, u, ldu );
        /* Print right singular vectors */
        //print_matrix( "Right singular vectors (stored rowwise)", n, n, vt, ldvt );
        print_matrix( "Singular values", 1, n, s, 1 );

        /* Free workspace */
        free( (void*)work );
        exit( 0 );





}

/* Auxiliary routine: printing a matrix */
void print_matrix( char* desc, int m, int n, double* a, int lda ) {
        int i, j;
        printf( "\n %s\n", desc );
        for( i = 0; i < m; i++ ) {
                for( j = 0; j < n; j++ ) printf( " %6.2f", a[i+j*lda] );
                printf( "\n" );
        }
}
